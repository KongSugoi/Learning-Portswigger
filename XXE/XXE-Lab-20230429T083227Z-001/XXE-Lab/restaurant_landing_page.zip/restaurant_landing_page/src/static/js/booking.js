$("#reservation").on('submit', function(e){
    e.preventDefault();

    formData = "<reservation>";
    formData += "<name>" + $('#name').val() + "</name>"
    formData += "<email>" + $('#email').val() + "</email>"
    formData += "<mobile>" + $('#mobile').val() +"</mobile>"
    formData += "<date>" + $('#date').val() + "</date>"
    formData += "<time>" + $('#time').val() + "</time>"
    formData += "<person>" + $('#person option:selected').val() + "</person>"
    formData += "</reservation>";
    
    $.ajax({
        type: "POST",
        url: "/contact",
        contentType: "application/xml",
        data: formData,
        success: function(data) {
            console.log(data);
            $("#booking-msg").html(data);
        },
        error: function(xhr, ajaxOptions, thrownError){
            
        }
    });
});