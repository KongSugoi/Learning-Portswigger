import re, os, datetime, uuid, json, base64
from flask import (
    Flask,
    render_template_string,
    request,
    render_template,
    current_app,
    flash,
    redirect,
    url_for,
    session,
    make_response,
    Response,
    send_from_directory,
)
from lxml import etree

app = Flask(__name__)
app.secret_key = "t;q]TPkj_R,ev{hQCzWFs~@b-}d6r3<!2nSYcpBau+9"
flag = "ptitctf{d181aeeb19585263388e10f07de226a3}"

def xmlcheck(xml):
    xml = str(xml).lower()
    badwords = ("file://", "ftp://", "gopher://", "jar://")
    if any([re.search(w, xml) for w in badwords]):
        raise ValueError("Bad word detected.")
    

@app.route('/', methods=["GET","POST"])
def index():
    return render_template('index.html')

@app.route('/contact', methods=["POST"])
def contact():
    if request.content_type == "application/xml":
        xml = request.data
        try:
            xmlcheck(xml)
        except Exception as e:
            return make_response((str(e), 500, {
                "Accept":
                "application/xml"
            }))

        try:
            parser = etree.XMLParser(encoding="utf-8", no_network=False, huge_tree=True)
            doc = etree.fromstring(xml, parser)
            parsed_xml = etree.tostring(doc)

            #save to file or database at here
            #...
        except Exception as e:
            print("BINGO!!!")
            return make_response((str(e), 500, {
                "Accept":
                "application/xml"
            }))

        #save successful!
        return make_response(("Thank you for booking with us!", {
            "Accept":
            "application/xml"
        }))
    else:
        return make_response(("Content-Type unknown", 400, {
            "Accept":
            "application/xml"
        }))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=80)
